package com.cg.lab6.p1;

public class NameInvalidException extends Exception {
	public NameInvalidException() {
		super();
		
	}

	public NameInvalidException(String arg0) {
		super(arg0);
		
	}
}

package com.cg.eis.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}

	public EmployeeException(String arg0) {
		super(arg0);
	}

}

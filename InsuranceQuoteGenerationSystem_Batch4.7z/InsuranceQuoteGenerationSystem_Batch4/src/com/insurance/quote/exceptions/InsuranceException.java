package com.insurance.quote.exceptions;

public class InsuranceException extends Exception{
	
	
	private static final long serialVersionUID = 1L;

	public InsuranceException(String message) {
		
		super(message);
	}

	

}

package com.insurance.quote.implimentation;

import java.util.List;
import java.util.Scanner;

import com.insurance.quote.beans.Policy;
import com.insurance.quote.dao.InsuranceService;
import com.insurance.quote.dao.InsuranceServiceImpl;
import com.insurance.quote.exceptions.InsuranceException;

public class ViewPolicy {

	InsuranceService service=new InsuranceServiceImpl();
	public List<Policy> viewPolicyDetails() throws InsuranceException{
		/*Scanner sc = new Scanner(System.in);
		long AccountNo=0;*/
		List<Policy> list=null;
		try {
			/*AccountNo=sc.nextLong();
			list=service.viewPolicyDetails(AccountNo);*/
			list=service.viewPolicyDetails();
		} catch (InsuranceException e) {
			System.err.println(e.getMessage());
		}
		
		return list;
		
	}
	public Policy getPolicy(String userName)throws InsuranceException {
		
		return service.getPolicy(userName);
	}

}

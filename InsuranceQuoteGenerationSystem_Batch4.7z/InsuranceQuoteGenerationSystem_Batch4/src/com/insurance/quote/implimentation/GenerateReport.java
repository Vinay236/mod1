package com.insurance.quote.implimentation;

import java.util.List;

import com.insurance.quote.beans.ReportGeneration;
import com.insurance.quote.dao.InsuranceService;
import com.insurance.quote.dao.InsuranceServiceImpl;
import com.insurance.quote.exceptions.InsuranceException;

public class GenerateReport {

	InsuranceService insuranceService= new InsuranceServiceImpl();

	public List<ReportGeneration> generateReport(int accountNumber1) throws InsuranceException{
		return insuranceService.generateReport(accountNumber1);
		
	}
}

package com.insurance.quote.implimentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.insurance.quote.beans.Policy;
import com.insurance.quote.dao.InsuranceService;
import com.insurance.quote.dao.InsuranceServiceImpl;
import com.insurance.quote.exceptions.InsuranceException;
import com.insurance.quote.implimentation.AccountCreation;
import com.insurance.quote.implimentation.ViewPolicy;
import com.insurance.quote.iqgpresentation.IQGMain;

public class Insured {

	AccountCreation accountCreation = new AccountCreation();
	ViewPolicy viewPolicy = new ViewPolicy();
	IQGMain main = new IQGMain();

	public void insured(String userName) {
		Scanner scanner = null;
		InsuranceService service = new InsuranceServiceImpl();
		int choice = 0;
		boolean choiceFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("1.Create Account");
			System.out.println("2.View Policy");
			System.out.println("9.Logout");
			System.out.println();
			System.out.println("Enter Choice: ");
			try {
				choice = scanner.nextInt();
				choiceFlag=true;
				switch(choice) {
				case 1: 
					try {
						int accountNumber = accountCreation.createAccount(userName);
						System.out.println("Account created with account number " + accountNumber);

						boolean continueFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Do you want to logout (Y/N): ");
							String option = scanner.next();
							option = option.toLowerCase();
							if (option.equals("y")) {

								String[] arguments = new String[] {"123"};
								main.main(arguments);
							} else {
								if (option.equals("n")) {
									choiceFlag = false;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);

						} catch (Exception e) {
							System.out.println(e.getMessage());
						}
					break;
				case 2:
					ViewPolicy viewPolicy = new ViewPolicy();
					List<Policy> list = new ArrayList<>();
					try {

						list = viewPolicy.viewPolicyDetails();
						if (!list.isEmpty()) {
							System.out.println("-----------Policy View-----------");
							String format = String.format("%-20s %-20s %s", "Policy Number", "Premium Amount",
									"Account Number");
							System.out.println(format);
							for (Policy policy : list) {
								System.out.println(String.format("%-20s %-20s %s", policy.getPolicyNumber(),
										policy.getPolicyPremium(), policy.getAccountNumber()));
							}
						} else {
							System.out.println("No data Found...");
						}
						boolean continueFlag = false;
						do {
							System.out.println("Do you want to logout (Y/N): ");
							String option = scanner.next();
							option = option.toLowerCase();
							if (option.equals("y")) {

								String[] arguments = new String[] {"123"};
								 main.main(arguments);
							} else {
								if (option.equals("n")) {
									choiceFlag = false;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);

					} catch (InsuranceException e) {
						System.err.println(e.getMessage());
						choiceFlag = false;
					}
					break;
				case 9:
					/*System.out.println("Thank you visit again...");
					System.exit(0);*/
					 String[] arguments = new String[] {"123"};
					 main.main(arguments);
				default:
					System.err.println("Enter choice (1-5)");
					choiceFlag = false;
					break;
				}
				
			} catch (InputMismatchException e) {
				System.err.println("Enter digits only....");
				choiceFlag = false;
			} 

		} while (!choiceFlag);
		scanner.close();
	}
}

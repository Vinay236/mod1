package com.insurance.quote.implimentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.insurance.quote.beans.Policy;
import com.insurance.quote.dao.InsuranceService;
import com.insurance.quote.dao.InsuranceServiceImpl;
import com.insurance.quote.exceptions.InsuranceException;
import com.insurance.quote.implimentation.AccountCreation;
import com.insurance.quote.implimentation.CreatePolicy;
import com.insurance.quote.implimentation.GenerateReport;
import com.insurance.quote.implimentation.ProfileCreation;
import com.insurance.quote.implimentation.ViewPolicy;
import com.insurance.quote.iqgpresentation.IQGMain;

public class Agent {

	AccountCreation accountCreation = new AccountCreation();
	InsuranceService service = new InsuranceServiceImpl();
	ProfileCreation profileCreation = new ProfileCreation();
	CreatePolicy createPolicy = new CreatePolicy();
	GenerateReport generateReport = new GenerateReport();
	IQGMain main = new IQGMain();

	public void agent(String userName) {
		Scanner scanner = null;
		int choice = 0;
		boolean choiceFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("1.Create Account");
			System.out.println("2.Policy creation");
			System.out.println("3.View policy");
			System.out.println("9.logout");
			System.out.println();
			System.out.println("Enter choice: ");

			try {
				choice = scanner.nextInt();
				choiceFlag = true;
				switch (choice) {
				case 1:
					try {
						int accountNumber = accountCreation.createAccount(userName);
						System.out.println("Account created with account number " + accountNumber);
						boolean continueFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Do you want to logout (Y/N): ");
							String option = scanner.next();
							option = option.toLowerCase();
							if (option.equals("y")) {

								String[] arguments = new String[] {"123"};
								 main.main(arguments);
							} else {
								if (option.equals("n")) {
									choiceFlag = false;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);
						
						} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 2:
					boolean accountFlag = false;
					int accountNumber = 0;
					// int premiumNumber = 0;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter account number for which you want to create policy: ");
						try {
							accountNumber = scanner.nextInt();
							try {
								boolean validAccountNumber = service.validAccountNumber(accountNumber);
								if (validAccountNumber == true) {
									accountFlag = true;
									boolean existAccount = service.existAccount(accountNumber);
									if (existAccount) {
										createPolicy.createPolicy(accountNumber);
										//scanner.nextLine();
									} else {
										System.err.println("Account number does not exist.....");
									}
									boolean continueFlag = false;
									do {
										System.out.println("Do you want to logout (Y/N): ");
										scanner = new Scanner(System.in);
										String wish="";
										wish = scanner.nextLine();
										
										wish = wish.toLowerCase();
										if (wish.equals("y")) {

											String[] arguments = new String[] {"123"};
											 main.main(arguments);
										} else {
											if (wish.equals("n")) {
												choiceFlag = false;
												continueFlag = true;
											} else {
												choiceFlag = true;
												continueFlag = false;
												System.err.println("Enter Y or N.");
											}
										}
									} while (!continueFlag);
								} else {
									System.err.println("Account number should be of 7 digits..");
								}
							} catch (InsuranceException e) {
								System.err.println(e.getMessage());
							}
							} catch (InputMismatchException e) {
							System.err.println("Enter digits only...");
							accountFlag = false;
						}
					} while (!accountFlag);
					break;
				case 3:
					ViewPolicy viewPolicy = new ViewPolicy();
					List<Policy> list = new ArrayList<>();
					try {

						list = viewPolicy.viewPolicyDetails();
						if (!list.isEmpty()) {
							System.out.println("-----------Policy View-----------");
							String format = String.format("%-20s %-20s %s", "Policy Number", "Premium Amount",
									"Account Number");
							System.out.println(format);
							for (Policy policy : list) {
								System.out.println(String.format("%-20s %-20s %s", policy.getPolicyNumber(),
										policy.getPolicyPremium(), policy.getAccountNumber()));
							}
						} else {
							System.out.println("No data Found...");
						}
						boolean continueFlag = false;
						do {
							System.out.println("Do you want to logout (Y/N): ");
							String wish = scanner.next();
							wish = wish.toLowerCase();
							if (wish.equals("y")) {

								String[] arguments = new String[] {"123"};
								 main.main(arguments);
							} else {
								if (wish.equals("n")) {
									choiceFlag = false;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);

					} catch (InsuranceException e) {
						System.err.println(e.getMessage());
						choiceFlag = false;
					}
					break;
				case 9:
					/*System.out.println("Thank you visit again");
					System.exit(0);*/
					String[] arguments = new String[] {"123"};
					 main.main(arguments);
				default:
					System.err.println("Enter choice (1-4)");
					choiceFlag = false;
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Enter digits only...");
				choiceFlag = false;
			}

		} while (!choiceFlag);
		System.out.println("Thank you visit again");
		scanner.close();
	}
}

package com.insurance.quote.implimentation;

import java.util.InputMismatchException;

import java.util.Scanner;

import com.insurance.quote.beans.Account;
import com.insurance.quote.dao.InsuranceService;
import com.insurance.quote.dao.InsuranceServiceImpl;
import com.insurance.quote.exceptions.InsuranceException;

public class AccountCreation {

	Scanner scanner=null;
	int accountNumber=0;
	InsuranceService service=new InsuranceServiceImpl();
	public int createAccount( String userName){
		String insuredName = "";
		String insuredStreet = "";
		String insuredCity = "";
		String insuredState = "";
		int insuredZip = 0;
		String businessSeg = "";
		
		boolean zipFlag = false;
		scanner=new Scanner(System.in);
		System.out.println("Enter insured Name: ");
		insuredName = scanner.nextLine();

		System.out.println("Enter insured Street: ");
		insuredStreet = scanner.nextLine();

		System.out.println("Enter insured City: ");
		insuredCity = scanner.nextLine();

		System.out.println("Enter insured State: ");
		insuredState = scanner.nextLine();

		do {
			System.out.println("Enter insured Zip: ");
			scanner = new Scanner(System.in);
			try {

				insuredZip = scanner.nextInt();
				zipFlag = true;

			} catch (InputMismatchException e) {

				System.err.println("Enter digits only");
				zipFlag = false;
			}

		} while (!zipFlag);

		scanner.nextLine();

		System.out.println("Enter business Segment: ");
		System.out.println("'BusinessAuto' or 'Restaurant' or 'Apartment' or 'GeneralMerchant'");
		businessSeg = scanner.nextLine();
		
		Account accounts=new Account(insuredName, insuredStreet, insuredCity, insuredState, insuredZip, businessSeg,userName);
		boolean flag=false;
		try {
			flag = service.validFields(accounts);
		} catch (InsuranceException e1) {
			
			e1.printStackTrace();
		}
		if(flag==true)
		{
			try {
					accountNumber=service.createAccount(accounts);
			
			}catch (InsuranceException e) {
				System.err.println(e.getMessage());
			}			
		}
		return accountNumber;
	}
}

package com.cg.iqg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.iqg.dao.AccountDao;
import com.cg.iqg.dao.LoginDao;
import com.cg.iqg.dao.ProfileCreationDao;
import com.cg.iqg.model.Accounts;
import com.cg.iqg.model.UserRole;


@SuppressWarnings("unused")
public class TestInsuranceQuoteGeneration {

	

	@Test
	public void testValidLogIn() {
		UserRole role=new UserRole("admin", "admin");
		try {
			boolean userRole=LoginDao.validate(role);
			assertTrue(userRole);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testCreateAccount() {
		Accounts accounts=new Accounts("Abhishek A", "Gurudwara Chowk", "Pune", "Maharashtra", 41103, "gen_mer", "abhishek");
		
		try {
			long accountValidation = AccountDao.createAccount(accounts);
			assertNotNull(accountValidation);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testAddProfile() {
		UserRole role1=new UserRole("abhi1235", "abhi1235", "Agent");
		try {
			boolean addProfileTest = ProfileCreationDao.createProfile(role1);
			assertTrue(addProfileTest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testCheckExist() {
		Accounts accounts=new Accounts("Abhishek", "Gurudwara Chowk", "Pune", "Maharashtra", 41103, "gen_mer", "abhishek");
		try {
			boolean userExistTest = AccountDao.userExist(accounts);
			assertTrue(userExistTest);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

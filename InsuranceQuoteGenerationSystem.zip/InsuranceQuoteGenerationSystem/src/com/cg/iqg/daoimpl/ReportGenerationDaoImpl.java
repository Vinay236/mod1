package com.cg.iqg.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.iqg.dao.PolicyCreationDao;
import com.cg.iqg.dao.ReportGenerationDao;
import com.cg.iqg.model.Policy;
import com.cg.iqg.model.PolicyDetails;
import com.cg.iqg.model.ReportGeneration;

@WebServlet("/PolPremium")
public class ReportGenerationDaoImpl extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    
	    long policy_num=Long.parseLong(request.getParameter("pol_num"));
	    
	    ReportGeneration report = ReportGenerationDao.reportGeneration(policy_num);
	    
	    out.println("<head>\r\n" + 
	    		"        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css\">\r\n" + 
	    		"\r\n" + 
	    		"        <!-- jQuery library -->\r\n" + 
	    		"        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>\r\n" + 
	    		"        \r\n" + 
	    		"        <!-- Latest compiled JavaScript -->\r\n" + 
	    		"        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>\r\n" + 
	    		"    <meta charset=\"utf-8\" />\r\n" + 
	    		"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	    		"    <title></title>\r\n" + 
	    		"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n" + 
	    		"    <link rel=\"stylesheet\" type=\"text/css\" media=\"screen\" href=\"main.css\" />\r\n" + 
	    		"    <script src=\"main.js\"></script>\r\n" + 
	    		"</head><nav class=\"navbar navbar-inverse\">\r\n" + 
	    		"        <div class=\"container-fluid\">\r\n" + 
	    		"            <a class=\"navbar-brand text-center\" href=\"#\">Insurance Quote Generation System</a>\r\n" + 
	    		"        </div>\r\n" + 
	    		"    </nav><center><h3>Policy Number: "+policy_num+"</h3><table border=\"2px\" cellspacing=\"3px\" cellpadding=\"2px\">");
	    out.println("<tr><td>Insured Name: </td><td>"+report.getInsuredName()+"</td></tr>");
	    out.println("<tr><td>Insured Street: </td><td>"+report.getInsuredStreet()+"</td></tr>");
	    out.println("<tr><td>Insured City: </td><td>"+report.getInsuredCity()+"</td></tr>");
	    out.println("<tr><td>Insured State: </td><td>"+report.getInsuredState()+"</td></tr>");
	    out.println("<tr><td>Insured Zip: </td><td>"+report.getInsuredZip()+"</td></tr>");
	    out.println("<tr><td>Business Segment: </td><td>"+report.getBusinessSegment()+"</td></tr>");
	    List<String> q = new ArrayList<String>();
	    q = report.getPolicyQuestion();
	    int i=1;
	    for(String ques : q) {
	    out.println("<tr><td>Policy Question "+i+" : </td><td>"+ques+"</td></tr>");
	    i++;
	    }
	    List<String> a = new ArrayList<String>();
	    a = report.getPolicyAnswer();
	    int j=1;
	    for(String ans : a) {
	    out.println("<tr><td>Policy Answer "+j+" : </td><td>"+ans+"</td></tr><br>");
	    j++;
	    }
	    out.println("<tr><td>Policy Premium: </td><td>"+report.getPolicyPremium()+"</td></tr><br></table></center><br><br><br>");
	    out.close();  
	    }  
	}  

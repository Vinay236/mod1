package com.cg.iqg.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.iqg.dao.AccountDao;
import com.cg.iqg.dao.PolicyCreationDao;
import com.cg.iqg.model.Accounts;
import com.cg.iqg.model.Policy;
import com.cg.iqg.model.PolicyDetails;

@WebServlet("/PolicyCreation")
public class PolicyCreationDaoImpl extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    
	    Long acc = Long.parseLong(request.getParameter("acc_no"));     
	   
	    Policy policy = new Policy(6000.00, acc);
	    
	    PolicyCreationDao.createPolicy(policy);
	    
	    String bus_type = PolicyCreationDao.getBusType(policy);
	    
	    long pol_num = PolicyCreationDao.getPolicyNumber(policy);
	    double sum=0;
	    System.out.println(pol_num);
	    
	    if(bus_type.equals("rest")) {
	       
	    	for(int i=111; i<120; i++) {
	    		String ques_id = PolicyCreationDao.getQuestionId(i);
	    		String ques_desc = PolicyCreationDao.getQuestionDesc(i);
	    		String ans = request.getParameter(Integer.toString(i));
	    		System.out.println(ans);
	    		PolicyDetails policy1 = new PolicyDetails(pol_num, ques_id, ans);
	    		PolicyCreationDao.insertPolicyDetails(policy1);
	    		sum += PolicyCreationDao.getWeightage(ques_desc, ans);
	    		System.out.println("in loop: "+sum);
	    }
	    	System.out.println("out loop: "+sum);
	    	PolicyCreationDao.updatePremium(pol_num, sum);
	    }else if(bus_type.equals("apt")) {
		       
		    	for(int i=120; i<128; i++) {
		    		String ques_id = PolicyCreationDao.getQuestionId(i);
		    		String ques_desc = PolicyCreationDao.getQuestionDesc(i);
		    		String ans = request.getParameter(Integer.toString(i));
		    		System.out.println(ans);
		    		PolicyDetails policy1 = new PolicyDetails(pol_num, ques_id, ans);
		    		PolicyCreationDao.insertPolicyDetails(policy1);
		    		sum += PolicyCreationDao.getWeightage(ques_id, ans);
		    		System.out.println(PolicyCreationDao.getWeightage(ques_desc, ans));
		    }
		    	PolicyCreationDao.updatePremium(pol_num, sum);
	    }else if(bus_type.equals("bus_auto")) {
		       
		    	for(int i=101; i<110; i++) {
		    		String ques_id = PolicyCreationDao.getQuestionId(i);
		    		String ques_desc = PolicyCreationDao.getQuestionDesc(i);
		    		String ans = request.getParameter(Integer.toString(i));
		    		System.out.println(ans);
		    		PolicyDetails policy1 = new PolicyDetails(pol_num, ques_id, ans);
		    		PolicyCreationDao.insertPolicyDetails(policy1);
		    		sum += PolicyCreationDao.getWeightage(ques_desc, ans);
		    }
		    	PolicyCreationDao.updatePremium(pol_num, sum);
	    }else {
		       
		    	for(int i=128; i<136; i++) {
		    		String ques_id = PolicyCreationDao.getQuestionId(i);
		    		String ques_desc = PolicyCreationDao.getQuestionDesc(i);
		    		String ans = request.getParameter(Integer.toString(i));
		    		System.out.println(ans);
		    		PolicyDetails policy1 = new PolicyDetails(pol_num, ques_id, ans);
		    		PolicyCreationDao.insertPolicyDetails(policy1);
		    		sum += PolicyCreationDao.getWeightage(ques_desc, ans);
		    }
		    	
		    	PolicyCreationDao.updatePremium(pol_num, sum);
	    }
	    out.close();  
	    }  
	}  

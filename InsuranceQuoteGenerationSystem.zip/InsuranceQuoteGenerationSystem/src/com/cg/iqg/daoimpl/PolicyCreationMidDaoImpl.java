package com.cg.iqg.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.iqg.dao.LoginDao;
import com.cg.iqg.dao.PolicyCreationMidDao;
import com.cg.iqg.model.UserRole;

@WebServlet("/PolicyCreationMid")
public class PolicyCreationMidDaoImpl extends HttpServlet{
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    long acc = Long.parseLong(request.getParameter("Acc_no"));  
	    
	    int bus_seg = PolicyCreationMidDao.getBusinessSegment(acc);
	    
	    if(bus_seg==101) {
	    	RequestDispatcher rd=request.getRequestDispatcher("Vehicle.jsp");  
	        rd.forward(request,response); 
	    }else if(bus_seg==102) {
	    	RequestDispatcher rd=request.getRequestDispatcher("Restaurant.jsp");  
	        rd.forward(request,response); 
	    }else if(bus_seg==103) {
	    	RequestDispatcher rd=request.getRequestDispatcher("Apartment.jsp");  
	        rd.forward(request,response); 
	    }else {
	    	RequestDispatcher rd=request.getRequestDispatcher("GeneralMerchant.jsp");  
	        rd.forward(request,response); 
	    }
	          
	    out.close();  
	    }  
	}  

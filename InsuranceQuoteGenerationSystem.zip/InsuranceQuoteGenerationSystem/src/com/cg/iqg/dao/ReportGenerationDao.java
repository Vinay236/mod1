package com.cg.iqg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.iqg.model.ReportGeneration;
import com.cg.iqg.utility.JDBCUtility;

public class ReportGenerationDao {

	public static ReportGeneration reportGeneration(long pol_num) {
		
		ReportGeneration report= new ReportGeneration();
try {
			
			Connection con = JDBCUtility.getConnection();
			
			List<String> ques = new ArrayList<String>();
			List<String> ans = new ArrayList<String>();
			
			
			PreparedStatement ps = ps = con.prepareStatement(QueryMapper.generatedReport);
			ps.setLong(1, pol_num);
			
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			String name = rs.getString(1);
			String street = rs.getString(2);
			String city = rs.getString(3);
			String state = rs.getString(4);
			int zip = rs.getInt(5);
			String bus_seg = rs.getString(6);
			ques.add(rs.getString(7));
			ans.add(rs.getString(8));
			double pol_prem = rs.getDouble(9);
			
			while(rs.next()) {
					ques.add(rs.getString(7));
					ans.add(rs.getString(8));
			}
			
			System.out.println(ques);
			System.out.println(ans);
			
			report = new ReportGeneration(name,street,city,state,zip,bus_seg,ques,ans,pol_prem);
			
			System.out.println(report);
			
		} catch (Exception e) {
			System.out.println(e);
		}
			return report;
	}
}

package com.cg.iqg.model;

public class Policy {

	private Integer policyNumber;
	private Double policyPremium;
	private Long accountNumber;
	private String userName;

	public Policy() {
		// TODO Auto-generated constructor stub
	}

	public Policy(Integer policyNumber, Double policyPremium, Long accountNumber, String userName) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		this.userName = userName;
	}

	public Policy(Double policyPremium, Long accountNumber, String userName) {
		super();
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		this.userName = userName;
	}
	

	public Policy(Integer policyNumber, Double policyPremium, Long accountNumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}
	
	public Policy(Double policyPremium, Long accountNumber) {
		super();
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}

	public Integer getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Integer policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(Double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Policy [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium + ", accountNumber="
				+ accountNumber + ", userName=" + userName + "]";
	}

}
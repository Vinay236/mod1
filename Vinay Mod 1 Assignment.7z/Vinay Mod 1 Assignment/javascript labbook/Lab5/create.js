var Width=document.getElementById(width);
document.write(Width);
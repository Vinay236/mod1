function dispHello()
{
	return("<code>This text is displayed by Calling external function :<b> Hello World</b></code>");
	//TODO:return the string “Hello World“
}